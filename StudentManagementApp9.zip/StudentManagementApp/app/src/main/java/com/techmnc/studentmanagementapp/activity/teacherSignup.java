package com.techmnc.studentmanagementapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.techmnc.studentmanagementapp.R;

public class teacherSignup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_signup);
    }
}